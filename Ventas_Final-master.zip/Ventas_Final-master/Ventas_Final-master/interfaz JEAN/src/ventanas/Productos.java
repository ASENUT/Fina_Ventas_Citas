package ventanas;

import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Productos extends javax.swing.JFrame {

    String values;

    public Productos() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("ASENUT - Productos");
        this.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logoASENUTbarra.PNG")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtBusqProd = new javax.swing.JTextField();
        cbxBusqProd = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnNuevo = new javax.swing.JMenu();
        btnEliminar = new javax.swing.JMenu();
        btnActualizar = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Productos"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Lupa.jpg"))); // NOI18N
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, 30, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Del Artículo", "Descripción", "Cantidad", "Fecha De Entrega"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 630, 150));
        getContentPane().add(txtBusqProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, 180, 30));

        cbxBusqProd.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Código", "Cantidad", "Fecha" }));
        getContentPane().add(cbxBusqProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 120, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 280));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/New.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnNuevoMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnNuevo);

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Delete.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEliminar);

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnActualizarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnActualizar);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/minimize-icon-17_2.png"))); // NOI18N
        jMenu1.setText("Minimizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        MenuAdministrativo m = new MenuAdministrativo();
        m.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu5MouseClicked

    private void btnNuevoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnNuevoMouseClicked
        // TODO add your handling code here:
        RegistroProductos rp = new RegistroProductos();
        rp.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnNuevoMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        //CARGAMOS LA TABLA DE PRODUCTOS
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        Conexion.Conectar();

        try {
            dtm.addColumn("Codigo");
            dtm.addColumn("Nombre");
            dtm.addColumn("Descripción");
            dtm.addColumn("Cantidad");
            dtm.addColumn("Fecha de Entrega");
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from PRODUCTOS");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        // ELIMINAR
        PreparedStatement cmd;
        try {
            cmd = ventanas.Conexion.link.prepareStatement("DELETE FROM PRODUCTOS WHERE COD_PRODUCTO = " + values);
            cmd.execute();
            JOptionPane.showMessageDialog(null, "Se eliminó con éxtio el producto");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar el producto deseado\n" + e);
        }
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnActualizarMouseClicked
        // ACTUALIZAR TABLA O RECARGAR CONEXION
        Conexion cn = new Conexion();
        cn.Conectar();

        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            dtm.addColumn("Codigo");
            dtm.addColumn("Nombre");
            dtm.addColumn("Descripción");
            dtm.addColumn("Cantidad");
            dtm.addColumn("Fecha de Entrega");
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from PRODUCTOS");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnActualizarMouseClicked

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        // BUSQUEDA
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        String variable = "";
        String bandera = "";
        variable = (String) cbxBusqProd.getSelectedItem();
        if ("Código".equals(variable)) {
            bandera = "COD_PRODUCTO";
        } else if ("Nombre".equals(variable)) {
            bandera = "NOM_PRODUCTO";
        } else if ("Cantidad".equals(variable)) {
            bandera = "STOCK";
        } else if ("Fecha".equals(variable)) {
            bandera = "FECHA_ENTREGA";
        }

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT * FROM PRODUCTOS WHERE " + bandera + " = '" + txtBusqProd.getText() + "'");
            int count = 0;
            while (rs.next()) {
                count++;
            }
            if (count == 0) {
                JOptionPane.showMessageDialog(null, "Ese producto no existe");
            } else {
                dtm.addColumn("Codigo");
                dtm.addColumn("Nombre");
                dtm.addColumn("Descripción");
                dtm.addColumn("Cantidad");
                dtm.addColumn("Fecha de Entrega");
                rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT * FROM PRODUCTOS WHERE " + bandera + " = '" + txtBusqProd.getText() + "'");
                while (rs.next()) {
                    dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
                }
                jTable1.setModel(dtm);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No se pudo realizar la búsqueda");
        }
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int filaseleccionada;

        try {
            filaseleccionada = jTable1.getSelectedRow();
            if (filaseleccionada == -1) {
                JOptionPane.showMessageDialog(null, "No se ha seleccionado ninguna fila");
            } else {
                DefaultTableModel modelo_tabla = (DefaultTableModel) jTable1.getModel();
                values = "'" + (String) (modelo_tabla.getValueAt(filaseleccionada, 0)) + "'";
                System.out.println(values);
            }
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex + "\nInténtelo nuevamente", " .::Error En la Operacion::.", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        this.setExtendedState(ICONIFIED);
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Productos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JMenu btnEliminar;
    private javax.swing.JMenu btnNuevo;
    private javax.swing.JComboBox cbxBusqProd;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField txtBusqProd;
    // End of variables declaration//GEN-END:variables
}
