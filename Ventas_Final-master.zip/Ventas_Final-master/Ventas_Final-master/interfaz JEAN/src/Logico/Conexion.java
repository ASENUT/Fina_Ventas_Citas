/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author MASTER
 */
public class Conexion {
    static String login = "root";
    static String pass = "villarruelsaenz";
    static String url = "jdbc:mysql://localhost:3306/asenut";

    public Conexion() {
    }
   
    
    public  Connection Conectar(){
        Connection link=null;
        try{
          Class.forName("org.gjt.mm.mysql.Driver");
            link=DriverManager.getConnection(this.url, this.login, this.pass);
        }catch(ClassNotFoundException | SQLException e){
          JOptionPane.showConfirmDialog(null, e);
      }
        return link;
    }
}
